package com.jhongpananon.sqlite_project.Features.CreateAddress;

public interface AddressCreateListener {
    void onAddressCreated(Address address);
}
